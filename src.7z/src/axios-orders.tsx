import axios from 'axios';
const instance = axios.create({
  baseURL: 'https://react-my-burger-aabb3.firebaseio.com/',
});

export default instance;
